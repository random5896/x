#include <bits/stdc++.h>
using namespace std;

struct Record {
    string outlook;
    double temperature;
    double humidity;
    string windy;
    string play;
};

// Split a string by delimiter
vector<string> split(const string &line, char delimiter = ',') {
    vector<string> tokens;
    string token;
    stringstream ss(line);
    while (getline(ss, token, delimiter))
        tokens.push_back(token);
    return tokens;
}

// Entropy calculation
double entropy(const vector<Record> &data) {
    int yes = 0, no = 0;
    for (auto &r : data) {
        if (r.play == "yes") yes++;
        else no++;
    }
    if (yes == 0 || no == 0) return 0.0;
    double p1 = (double)yes / (yes + no);
    double p2 = (double)no / (yes + no);
    return -p1 * log2(p1) - p2 * log2(p2);
}

// Compute information gain for binary split on numeric attribute
double infoGainNumeric(const vector<Record> &data, const string &attr) {
    vector<double> values;
    for (auto &r : data) {
        if (attr == "temperature") values.push_back(r.temperature);
        else if (attr == "humidity") values.push_back(r.humidity);
    }
    sort(values.begin(), values.end());
    values.erase(unique(values.begin(), values.end()), values.end());

    double baseEntropy = entropy(data);
    double bestGain = 0.0;

    for (size_t i = 0; i < values.size() - 1; i++) {
        double threshold = (values[i] + values[i + 1]) / 2.0;
        vector<Record> left, right;

        for (auto &r : data) {
            double val = (attr == "temperature") ? r.temperature : r.humidity;
            if (val <= threshold)
                left.push_back(r);
            else
                right.push_back(r);
        }

        double newEntropy = (left.size() * entropy(left) + right.size() * entropy(right)) / data.size();
        double gain = baseEntropy - newEntropy;
        bestGain = max(bestGain, gain);
    }
    return bestGain;
}

// Compute information gain for categorical attribute
double infoGainCategorical(const vector<Record> &data, const string &attr) {
    double baseEntropy = entropy(data);
    map<string, vector<Record>> subsets;

    for (auto &r : data) {
        string key;
        if (attr == "outlook") key = r.outlook;
        else if (attr == "windy") key = r.windy;
        subsets[key].push_back(r);
    }

    double newEntropy = 0.0;
    for (auto &p : subsets)
        newEntropy += (p.second.size() * entropy(p.second)) / data.size();

    return baseEntropy - newEntropy;
}

int main() {
    ifstream file("data.csv");
    if (!file.is_open()) {
        cerr << "Error: Cannot open CSV file.\n";
        return 1;
    }

    string line;
    getline(file, line); // skip header
    vector<Record> data;

    while (getline(file, line)) {
        vector<string> row = split(line, ',');
        if (row.size() != 5) continue;
        Record r;
        r.outlook = row[0];
        r.temperature = stod(row[1]);
        r.humidity = stod(row[2]);
        r.windy = row[3];
        r.play = row[4];
        data.push_back(r);
    }
    file.close();

    cout << fixed << setprecision(4);

    double gainOutlook = infoGainCategorical(data, "outlook");
    double gainWindy = infoGainCategorical(data, "windy");
    double gainTemp = infoGainNumeric(data, "temperature");
    double gainHum = infoGainNumeric(data, "humidity");

    cout << "\nInformation Gain for attributes:\n";
    cout << "Outlook      = " << gainOutlook << endl;
    cout << "Temperature  = " << gainTemp << endl;
    cout << "Humidity     = " << gainHum << endl;
    cout << "Windy        = " << gainWindy << endl;

    double bestGain = max({gainOutlook, gainTemp, gainHum, gainWindy});

    cout << "\nBest Attribute to Split: ";
    if (bestGain == gainOutlook) cout << "Outlook";
    else if (bestGain == gainTemp) cout << "Temperature";
    else if (bestGain == gainHum) cout << "Humidity";
    else cout << "Windy";

    cout << " (Gain = " << bestGain << ")\n";

    return 0;
}
