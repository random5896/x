#include <bits/stdc++.h>
using namespace std;

struct Record {
    string outlook, tempLevel, humidLevel, windy, play;
};

// Function to convert temperature into label
string tempLabel(double t) {
    if (t >= 80) return "High";
    else if (t >= 65) return "Medium";
    else return "Low";
}

// Function to convert humidity into label
string humidLabel(double h) {
    if (h >= 85) return "High";
    else if (h >= 70) return "Medium";
    else return "Low";
}

// Split CSV line
vector<string> split(const string &line, char delimiter = ',') {
    vector<string> tokens;
    string token;
    stringstream ss(line);
    while (getline(ss, token, delimiter))
        tokens.push_back(token);
    return tokens;
}

int main() {
    string filename = "data.csv";
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error opening file.\n";
        return 1;
    }

    vector<Record> data;
    string line;
    getline(file, line); // skip header

    while (getline(file, line)) {
        vector<string> row = split(line, ',');
        if (row.size() != 5) continue;

        Record r;
        r.outlook = row[0];
        r.tempLevel = tempLabel(stod(row[1]));
        r.humidLevel = humidLabel(stod(row[2]));
        r.windy = row[3];
        r.play = row[4];
        data.push_back(r);
    }
    file.close();

    // Input test case
    double t, h;
    Record test;
    cout << "Enter details to predict (Outlook Temperature Humidity Windy):\n";
    cin >> test.outlook >> t >> h >> test.windy;
    test.tempLevel = tempLabel(t);
    test.humidLevel = humidLabel(h);

    // Count totals for class labels
    map<string, int> classCount;
    for (auto &r : data) classCount[r.play]++;
    int total = data.size();

    double probYes = (double)classCount["yes"] / total;
    double probNo = (double)classCount["no"] / total;

    // Conditional frequency tables
    map<string, map<string, int>> outlookYes, tempYes, humidYes, windyYes;
    map<string, map<string, int>> outlookNo, tempNo, humidNo, windyNo;

    for (auto &r : data) {
        if (r.play == "yes") {
            outlookYes["yes"][r.outlook]++;
            tempYes["yes"][r.tempLevel]++;
            humidYes["yes"][r.humidLevel]++;
            windyYes["yes"][r.windy]++;
        } else {
            outlookNo["no"][r.outlook]++;
            tempNo["no"][r.tempLevel]++;
            humidNo["no"][r.humidLevel]++;
            windyNo["no"][r.windy]++;
        }
    }

    // Conditional probabilities (with Laplace smoothing)
    double pOutYes = (double)(outlookYes["yes"][test.outlook] + 1) / (classCount["yes"] + 3);
    double pTempYes = (double)(tempYes["yes"][test.tempLevel] + 1) / (classCount["yes"] + 3);
    double pHumidYes = (double)(humidYes["yes"][test.humidLevel] + 1) / (classCount["yes"] + 3);
    double pWindyYes = (double)(windyYes["yes"][test.windy] + 1) / (classCount["yes"] + 3);

    double pOutNo = (double)(outlookNo["no"][test.outlook] + 1) / (classCount["no"] + 3);
    double pTempNo = (double)(tempNo["no"][test.tempLevel] + 1) / (classCount["no"] + 3);
    double pHumidNo = (double)(humidNo["no"][test.humidLevel] + 1) / (classCount["no"] + 3);
    double pWindyNo = (double)(windyNo["no"][test.windy] + 1) / (classCount["no"] + 3);

    // Final probabilities
    double yesProb = probYes * pOutYes * pTempYes * pHumidYes * pWindyYes;
    double noProb = probNo * pOutNo * pTempNo * pHumidNo * pWindyNo;

    cout << "\nP(Yes) = " << yesProb;
    cout << "\nP(No)  = " << noProb;
    cout << "\nPredicted Class (Play): " << (yesProb > noProb ? "YES" : "NO") << endl;

    return 0;
}
