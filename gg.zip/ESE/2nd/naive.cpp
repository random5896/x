#include <bits/stdc++.h>
using namespace std;

struct Day {
    string tempLevel;   // High / Medium / Low
    string humidityLevel;
    string outlook;     // sunny / rainy / overcast
    string windy;       // true / false
    string play;        // yes / no
};

// Function to categorize temperature
string tempCategory(double t) {
    if (t >= 80) return "High";
    else if (t >= 65) return "Medium";
    else return "Low";
}

// Function to categorize humidity
string humidityCategory(double h) {
    if (h >= 80) return "High";
    else if (h >= 60) return "Medium";
    else return "Low";
}

int main() {
    ifstream file("2.csv");
    if (!file.is_open()) {
        cerr << "Error: Cannot open file\n";
        return 1;
    }

    string line;
    getline(file, line); // skip header
    vector<Day> data;

    // Read CSV
    while (getline(file, line)) {
        stringstream ss(line);
        string token;
        vector<string> row;
        while (getline(ss, token, ',')) row.push_back(token);

        if (row.size() != 5) continue;

        Day d;
        d.tempLevel = tempCategory(stod(row[0]));
        d.humidityLevel = humidityCategory(stod(row[1]));
        d.outlook = row[2];
        d.windy = row[3];
        d.play = row[4];
        data.push_back(d);
    }
    file.close();

    // Count totals
    int yesCount = 0, noCount = 0;
    for (auto &d : data) {
        if (d.play == "yes") yesCount++;
        else noCount++;
    }
    int total = data.size();

    // Frequency table: freq[class][attribute][value]
    map<string, map<string, map<string, int>>> freq;

    for (auto &d : data) {
        freq[d.play]["temp"][d.tempLevel]++;
        freq[d.play]["humidity"][d.humidityLevel]++;
        freq[d.play]["outlook"][d.outlook]++;
        freq[d.play]["windy"][d.windy]++;
    }

    // Take test input
    double temp, humidity;
    string outlook, windy;
    cout << "Enter Temperature: ";
    cin >> temp;
    cout << "Enter Humidity: ";
    cin >> humidity;
    cout << "Enter Outlook (sunny/rainy/overcast): ";
    cin >> outlook;
    cout << "Is it windy? (true/false): ";
    cin >> windy;

    string tempL = tempCategory(temp);
    string humL = humidityCategory(humidity);

    // Calculate probabilities
    double pYes = (double)yesCount / total;
    double pNo = (double)noCount / total;

    pYes *= (double)(freq["yes"]["temp"][tempL] + 1) / (yesCount + 3);
    pYes *= (double)(freq["yes"]["humidity"][humL] + 1) / (yesCount + 3);
    pYes *= (double)(freq["yes"]["outlook"][outlook] + 1) / (yesCount + 3);
    pYes *= (double)(freq["yes"]["windy"][windy] + 1) / (yesCount + 2);

    pNo *= (double)(freq["no"]["temp"][tempL] + 1) / (noCount + 3);
    pNo *= (double)(freq["no"]["humidity"][humL] + 1) / (noCount + 3);
    pNo *= (double)(freq["no"]["outlook"][outlook] + 1) / (noCount + 3);
    pNo *= (double)(freq["no"]["windy"][windy] + 1) / (noCount + 2);

    cout << "\nP(Play=Yes | Data) = " << pYes;
    cout << "\nP(Play=No  | Data) = " << pNo;
    cout << "\nPredicted Result: " << (pYes > pNo ? "YES" : "NO") << endl;

    return 0;
}
