#include <bits/stdc++.h>
using namespace std;

struct Employee {
    string name, exp, gender;
    double salary;
};

// Function to categorize salary
string salaryLevel(double s) {
    if (s >= 40000) return "High";
    else if (s >= 20000) return "Medium";
    else return "Low";
}

int main() {
    ifstream file("data.csv");
    if (!file.is_open()) {
        cerr << "Error: Cannot open file\n";
        return 1;
    }

    string line;
    getline(file, line); // skip header
    vector<Employee> data;

    // Read CSV
    while (getline(file, line)) {
        stringstream ss(line);
        string name, id, salaryStr, exp, gender, phone;
        getline(ss, name, ',');
        getline(ss, id, ',');
        getline(ss, salaryStr, ',');
        getline(ss, exp, ',');
        getline(ss, gender, ',');
        getline(ss, phone, ',');

        Employee e;
        e.name = name;
        e.salary = stod(salaryStr);
        e.exp = exp;
        e.gender = gender;
        data.push_back(e);
    }
    file.close();

    // Count totals per class (exp)
    map<string, int> expCount;
    for (auto &e : data)
        expCount[e.exp]++;

    int total = data.size();

    // Frequency tables
    map<string, map<string, int>> genderFreq; // exp -> gender -> count
    map<string, map<string, int>> salaryFreq; // exp -> salaryLevel -> count

    for (auto &e : data) {
        string sLevel = salaryLevel(e.salary);
        genderFreq[e.exp][e.gender]++;
        salaryFreq[e.exp][sLevel]++;
    }

    // Take test input
    double testSalary;
    string testGender;
    cout << "Enter test salary: ";
    cin >> testSalary;
    cout << "Enter gender (male/female): ";
    cin >> testGender;

    string testSalaryLevel = salaryLevel(testSalary);

    // Calculate probabilities for each class (low/medium/high)
    map<string, double> prob;
    for (auto &cls : expCount) {
        string c = cls.first;
        double pClass = (double)expCount[c] / total;

        double pGender = (double)(genderFreq[c][testGender] + 1) / (expCount[c] + 2);
        double pSalary = (double)(salaryFreq[c][testSalaryLevel] + 1) / (expCount[c] + 3);

        prob[c] = pClass * pGender * pSalary;
    }

    // Find class with max probability
    string predictedClass;
    double maxP = -1;
    for (auto &p : prob) {
        if (p.second > maxP) {
            maxP = p.second;
            predictedClass = p.first;
        }
    }

    // Display results
    cout << "\nConditional Probabilities:\n";
    for (auto &p : prob)
        cout << "P(" << p.first << "|data) = " << p.second << endl;

    cout << "\nPredicted Experience Level: " << predictedClass << endl;

    return 0;
}
