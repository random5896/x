#include <bits/stdc++.h>
using namespace std;

// Structure to hold data
struct Record {
    string name;
    double salary;
};

int main() {
    // Step 1: Read data from CSV
    string filename = "data.csv";
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error opening file!" << endl;
        return 1;
    }

    string line;
    getline(file, line); // skip header
    vector<Record> data;

    while (getline(file, line)) {
        stringstream ss(line);
        string name, id, salaryStr, exp, gender, phone;
        getline(ss, name, ',');
        getline(ss, id, ',');
        getline(ss, salaryStr, ',');
        getline(ss, exp, ',');
        getline(ss, gender, ',');
        getline(ss, phone, ',');

        Record r;
        r.name = name;
        r.salary = stod(salaryStr);
        data.push_back(r);
    }
    file.close();

    int k = 3; // Number of clusters
    vector<double> centroids;
    srand(time(0));

    // Step 2: Initialize random centroids
    for (int i = 0; i < k; i++) {
        centroids.push_back(data[rand() % data.size()].salary);
    }

    vector<int> cluster(data.size(), -1);
    bool changed = true;
    int iter = 0;

    // Step 3: Repeat until centroids stabilize
    while (changed && iter < 100) {
        changed = false;
        iter++;

        // Assign points to nearest centroid
        for (size_t i = 0; i < data.size(); i++) {
            double minDist = 1e9;
            int clusterIndex = -1;

            for (int j = 0; j < k; j++) {
                double dist = fabs(data[i].salary - centroids[j]);
                if (dist < minDist) {
                    minDist = dist;
                    clusterIndex = j;
                }
            }

            if (cluster[i] != clusterIndex) {
                cluster[i] = clusterIndex;
                changed = true;
            }
        }

        // Update centroids
        vector<double> sum(k, 0);
        vector<int> count(k, 0);
        for (size_t i = 0; i < data.size(); i++) {
            sum[cluster[i]] += data[i].salary;
            count[cluster[i]]++;
        }
        for (int j = 0; j < k; j++) {
            if (count[j] > 0)
                centroids[j] = sum[j] / count[j];
        }
    }

    // Step 4: Display results
    cout << "\nFinal Cluster Centers:\n";
    for (int j = 0; j < k; j++)
        cout << "Cluster " << j + 1 << " -> " << centroids[j] << endl;

    cout << "\nCluster Assignments:\n";
    for (size_t i = 0; i < data.size(); i++)
        cout << data[i].name << " (Salary: " << data[i].salary << ") -> Cluster " << cluster[i] + 1 << endl;

    return 0;
}
