#include <bits/stdc++.h>
using namespace std;

struct Student {
    vector<string> levels; // High/Medium/Low for each course
    string result;
};

// Function to convert marks to category
string level(double m) {
    if (m >= 60) return "High";
    else if (m >= 40) return "Medium";
    else return "Low";
}

int main() {
    ifstream file("1.csv");
    if (!file.is_open()) {
        cerr << "Error: Cannot open file\n";
        return 1;
    }

    string line;
    vector<Student> data;
    getline(file, line); // skip header

    // Read CSV
    while (getline(file, line)) {
        stringstream ss(line);
        string token;
        vector<string> row;
        while (getline(ss, token, ',')) row.push_back(token);

        Student s;
        for (int i = 2; i <= 7; i++)
            s.levels.push_back(level(stod(row[i])));
        s.result = row[9];
        data.push_back(s);
    }
    file.close();

    // Count totals
    int passCount = 0, failCount = 0;
    for (auto &s : data) {
        if (s.result == "PASS") passCount++;
        else failCount++;
    }
    int total = data.size();

    // Conditional frequency tables
    map<string, map<int, map<string, int>>> freq; 
    // freq[class][courseIndex][level]

    for (auto &s : data) {
        for (int i=0; i<6; i++)
            freq[s.result][i][s.levels[i]]++;
    }

    // Test data
    vector<double> testMarks(6);
    cout << "Enter marks for 6 courses:\n";
    for (int i=0; i<6; i++) cin >> testMarks[i];

    vector<string> testLevel(6);
    for (int i=0; i<6; i++) testLevel[i] = level(testMarks[i]);

    // Calculate conditional probabilities
    double pPass = (double)passCount / total;
    double pFail = (double)failCount / total;

    for (int i=0; i<6; i++) {
        pPass *= (double)(freq["PASS"][i][testLevel[i]] + 1) / (passCount + 3); 
        pFail *= (double)(freq["FAIL"][i][testLevel[i]] + 1) / (failCount + 3);
    }

    cout << "\nP(PASS|data) = " << pPass;
    cout << "\nP(FAIL|data) = " << pFail;
    cout << "\nPredicted Result: " << (pPass > pFail ? "PASS" : "FAIL") << endl;

    return 0;
}
