#include <bits/stdc++.h>
using namespace std;

struct Student {
    string name;
    vector<double> marks; // Course1–6 + Total
};

// Function to calculate Euclidean distance between two points
double distanceEuclidean(const vector<double>& a, const vector<double>& b) {
    double sum = 0.0;
    for (size_t i = 0; i < a.size(); i++)
        sum += pow(a[i] - b[i], 2);
    return sqrt(sum);
}

// Function to compute mean (centroid) of a cluster
vector<double> computeCentroid(const vector<vector<double>>& cluster) {
    int n = cluster.size(), dim = cluster[0].size();
    vector<double> centroid(dim, 0.0);
    for (auto& point : cluster)
        for (int i = 0; i < dim; i++)
            centroid[i] += point[i];
    for (int i = 0; i < dim; i++)
        centroid[i] /= n;
    return centroid;
}

int main() {
    ifstream file("1.csv");
    if (!file.is_open()) {
        cerr << "Error: Cannot open file\n";
        return 1;
    }

    string line;
    vector<Student> data;
    getline(file, line); // skip header

    // Read CSV data
    while (getline(file, line)) {
        stringstream ss(line);
        string token;
        vector<string> row;
        while (getline(ss, token, ',')) row.push_back(token);

        Student s;
        s.name = row[1];
        for (int i = 2; i <= 8; i++)  // Course1–6 + Total
            s.marks.push_back(stod(row[i]));
        data.push_back(s);
    }
    file.close();

    int K = 2; // number of clusters (PASS/FAIL)
    int n = data.size();
    int dim = data[0].marks.size();

    // Initialize centroids (first two students)
    vector<vector<double>> centroids = {data[0].marks, data[1].marks};
    vector<int> labels(n, -1);

    bool changed = true;
    int iterations = 0;

    while (changed && iterations < 100) {
        changed = false;
        iterations++;

        // Step 1: Assign points to nearest centroid
        for (int i = 0; i < n; i++) {
            double minDist = 1e9;
            int bestCluster = -1;
            for (int k = 0; k < K; k++) {
                double d = distanceEuclidean(data[i].marks, centroids[k]);
                if (d < minDist) {
                    minDist = d;
                    bestCluster = k;
                }
            }
            if (labels[i] != bestCluster) {
                labels[i] = bestCluster;
                changed = true;
            }
        }

        // Reset cluster sums and counts
        vector<vector<double>> newCentroids(K, vector<double>(dim, 0.0));
        vector<int> count(K, 0);

        for (int i = 0; i < n; i++) {
            int c = labels[i];
            for (int j = 0; j < dim; j++)
                newCentroids[c][j] += data[i].marks[j];
            count[c]++;
        }

        for (int k = 0; k < K; k++) {
            if (count[k] > 0) {
                for (int j = 0; j < dim; j++)
                    newCentroids[k][j] /= count[k];
            }
        }

        centroids = newCentroids;

    }

    // Output final clusters
    cout << "K-Means Clustering Results (K=2):\n";
    for (int k = 0; k < K; k++) {
        cout << "\nCluster " << k + 1 << ":\n";
        for (int i = 0; i < n; i++) {
            if (labels[i] == k)
                cout << "  " << data[i].name << " (Total: " << data[i].marks[6] << ")\n";
        }
    }

    return 0;
}
