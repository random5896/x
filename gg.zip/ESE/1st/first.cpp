#include <bits/stdc++.h>
using namespace std;

struct Student {
    vector<double> marks;
    string result;
};

// Gaussian probability function
double gaussianProb(double x, double mean, double var) {
    if (var == 0) var = 1e-6; // avoid division by zero
    double p = (1.0 / sqrt(2 * M_PI * var)) * exp(-pow(x - mean, 2) / (2 * var));
    return p;
}

int main() {
    ifstream file("data.csv");
    if (!file.is_open()) {
        cerr << "Error: Cannot open file\n";
        return 1;
    }

    string line;
    vector<Student> data;
    getline(file, line); // skip header

    // Read data from CSV
    while (getline(file, line)) {
        stringstream ss(line);
        string token;
        vector<string> row;
        while (getline(ss, token, ',')) row.push_back(token);

        Student s;
        for (int i = 2; i <= 7; i++) s.marks.push_back(stod(row[i]));
        s.result = row[9];
        data.push_back(s);
    }
    file.close();

    // Separate PASS and FAIL data
    vector<vector<double>> passMarks, failMarks;
    for (auto &s : data) {
        if (s.result == "PASS") passMarks.push_back(s.marks);
        else failMarks.push_back(s.marks);
    }

    // Compute mean and variance
    vector<double> meanPass(6,0), meanFail(6,0), varPass(6,0), varFail(6,0);
    for (int i=0; i<6; i++) {
        for (auto &m : passMarks) meanPass[i] += m[i];
        for (auto &m : failMarks) meanFail[i] += m[i];
        meanPass[i] /= passMarks.size();
        meanFail[i] /= failMarks.size();
    }
    for (int i=0; i<6; i++) {
        for (auto &m : passMarks) varPass[i] += pow(m[i] - meanPass[i], 2);
        for (auto &m : failMarks) varFail[i] += pow(m[i] - meanFail[i], 2);
        varPass[i] /= passMarks.size();
        varFail[i] /= failMarks.size();
    }

    // Prior probabilities
    double priorPass = (double)passMarks.size() / data.size();
    double priorFail = (double)failMarks.size() / data.size();

    // Test input (user-provided)
    vector<double> test(6);
    cout << "Enter marks for 6 courses:\n";
    for (int i=0; i<6; i++) cin >> test[i];

    // Compute probabilities
    double passProb = log(priorPass);
    double failProb = log(priorFail);
    for (int i=0; i<6; i++) {
        passProb += log(gaussianProb(test[i], meanPass[i], varPass[i]));
        failProb += log(gaussianProb(test[i], meanFail[i], varFail[i]));
    }

    cout << "\nLog Probability (PASS): " << passProb;
    cout << "\nLog Probability (FAIL): " << failProb;

    cout << "\nPredicted Result: " << (passProb > failProb ? "PASS" : "FAIL") << endl;
    return 0;
}
