#include <bits/stdc++.h>
using namespace std;

struct Record {
    string gender, accno, bank, location, deposit;
};

// Function to split a CSV line
vector<string> split(const string &line, char delimiter = ',') {
    vector<string> tokens;
    string token;
    stringstream ss(line);
    while (getline(ss, token, delimiter))
        tokens.push_back(token);
    return tokens;
}

int main() {
    string filename = "data.csv"; // dataset filename
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Error opening file.\n";
        return 1;
    }

    vector<Record> data;
    string line;
    getline(file, line); // skip header

    while (getline(file, line)) {
        vector<string> row = split(line, ',');
        if (row.size() != 5) continue;
        Record r = {row[0], row[1], row[2], row[3], row[4]};
        data.push_back(r);
    }
    file.close();

    // Input test case
    Record test;
    cout << "Enter details to predict (Gender BankName Location):\n";
    cin >> test.gender >> test.bank >> test.location;

    // Count totals for class labels (deposit yes/no)
    map<string, int> classCount;
    for (auto &r : data) classCount[r.deposit]++;

    int total = data.size();
    double probYes = (double)classCount["yes"] / total;
    double probNo = (double)classCount["no"] / total;

    // Count attribute-wise conditional probabilities
    map<string, int> genderYes, bankYes, locYes;
    map<string, int> genderNo, bankNo, locNo;

    for (auto &r : data) {
        if (r.deposit == "yes") {
            genderYes[r.gender]++;
            bankYes[r.bank]++;
            locYes[r.location]++;
        } else {
            genderNo[r.gender]++;
            bankNo[r.bank]++;
            locNo[r.location]++;
        }
    }

    // Calculate conditional probabilities P(attr|yes) and P(attr|no)
    double pGenderYes = (double)genderYes[test.gender] / classCount["yes"];
    double pBankYes = (double)bankYes[test.bank] / classCount["yes"];
    double pLocYes = (double)locYes[test.location] / classCount["yes"];

    double pGenderNo = (double)genderNo[test.gender] / classCount["no"];
    double pBankNo = (double)bankNo[test.bank] / classCount["no"];
    double pLocNo = (double)locNo[test.location] / classCount["no"];

    // Apply Naive Bayes formula
    double yesProb = probYes * pGenderYes * pBankYes * pLocYes;
    double noProb = probNo * pGenderNo * pBankNo * pLocNo;

    cout << "\nP(Yes) = " << yesProb << "\nP(No) = " << noProb << endl;
    cout << "\nPredicted Deposit: " << (yesProb > noProb ? "YES" : "NO") << endl;

    return 0;
}
