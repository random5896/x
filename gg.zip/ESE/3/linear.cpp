#include <bits/stdc++.h>
using namespace std;

// Function to compute mean
double mean(const vector<double> &v) {
    double sum = 0;
    for (double x : v) sum += x;
    return sum / v.size();
}

int main() {
    ifstream file("3.csv");
    if (!file.is_open()) {
        cerr << "Error: Could not open file." << endl;
        return 1;
    }

    vector<double> age, salary;
    string line;
    getline(file, line); // Skip header line

    while (getline(file, line)) {
        stringstream ss(line);
        string ageStr, salaryStr, performance;
        getline(ss, ageStr, ',');
        getline(ss, salaryStr, ',');
        getline(ss, performance, ',');

        if (!ageStr.empty() && !salaryStr.empty()) {
            double a = stod(ageStr);
            double s = stod(salaryStr);
            salary.push_back(s / 1000.0); // convert to 'k' for simplicity
            age.push_back(a);
        }
    }

    file.close();

    int n = age.size();
    if (n == 0) {
        cerr << "No valid data found." << endl;
        return 1;
    }

    double mean_x = mean(age);
    double mean_y = mean(salary);

    // Compute slope (b1) and intercept (b0)
    double num = 0, den = 0;
    for (int i = 0; i < n; i++) {
        num += (age[i] - mean_x) * (salary[i] - mean_y);
        den += (age[i] - mean_x) * (age[i] - mean_x);
    }

    double m = num / den;
    double c = mean_y - m * mean_x;

    cout << fixed << setprecision(2);
    cout << "Linear Regression Equation: Salary = " << c << " + " << m << " * Age\n";

    double age_input;
    cout << "Enter age to predict salary: ";
    cin >> age_input;

    double predicted_salary = c + m * age_input;
    cout << "Predicted Salary: " << predicted_salary << "k\n";

    return 0;
}
