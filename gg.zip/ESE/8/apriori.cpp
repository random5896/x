#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include <set>
#include <algorithm>

using namespace std;

int min_support = 2;

typedef set<string> Itemset;
typedef vector<Itemset> TransactionList;
typedef map<Itemset, int> ItemsetCount;

void printItemsets(const ItemsetCount &freqItemsets) {
    for (const auto &entry : freqItemsets) {
        for (const auto &item : entry.first)
            cout << item << " ";
        cout << ": " << entry.second << endl;
    }
}

set<Itemset> generateCandidates(const vector<Itemset> &prevFreqItemsets, int k) {
    set<Itemset> candidates;

    for (size_t i = 0; i < prevFreqItemsets.size(); ++i) {
        for (size_t j = i + 1; j < prevFreqItemsets.size(); ++j) {
            Itemset a = prevFreqItemsets[i];
            Itemset b = prevFreqItemsets[j];

            vector<string> items;
            set_union(a.begin(), a.end(), b.begin(), b.end(), back_inserter(items));

            if ((int)items.size() == k) {
                Itemset candidate(items.begin(), items.end());
                candidates.insert(candidate);
            }
        }
    }

    return candidates;
}

ItemsetCount countSupport(const TransactionList &transactions, const set<Itemset> &candidates) {
    ItemsetCount counts;

    for (const auto &transaction : transactions) {
        for (const auto &candidate : candidates) {
            if (includes(transaction.begin(), transaction.end(), candidate.begin(), candidate.end())) {
                counts[candidate]++;
            }
        }
    }

    return counts;
}

vector<Itemset> getFrequentItemsets(const ItemsetCount &counts, int minSupport) {
    vector<Itemset> freqItemsets;
    for (const auto &entry : counts) {
        if (entry.second >= minSupport) {
            freqItemsets.push_back(entry.first);
        }
    }
    return freqItemsets;
}

TransactionList loadTransactionsFromCSV(const string &filename) {
    TransactionList transactions;
    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return transactions;
    }

    string line;
    while (getline(file, line)) {
        Itemset transaction;
        stringstream ss(line);
        string item;
        while (getline(ss, item, ',')) {
            // Trim spaces
            item.erase(0, item.find_first_not_of(" \t\n\r\f\v"));
            item.erase(item.find_last_not_of(" \t\n\r\f\v") + 1);
            if (!item.empty())
                transaction.insert(item);
        }
        if (!transaction.empty())
            transactions.push_back(transaction);
    }
    file.close();
    return transactions;
}

int main() {
    
    cout << "Enter path to CSV file containing transactions: ";
    string filepath;
    cin>>filepath;

    cout<<"\n Enter the Minimum Support :";
    cin>>min_support ;

    TransactionList transactions = loadTransactionsFromCSV(filepath);

    if (transactions.empty()) {
        cout << "No transactions loaded Exiting." << endl;
        return 1;
    }

    vector<Itemset> freqItemsetsAll;
    vector<Itemset> prevFreqItemsets;
    ItemsetCount itemCounts;
    for (auto &transaction : transactions) {
        for (auto &item : transaction) {
            itemCounts[{item}]++;
        }
    }

    prevFreqItemsets = getFrequentItemsets(itemCounts, min_support);
    freqItemsetsAll.insert(freqItemsetsAll.end(), prevFreqItemsets.begin(), prevFreqItemsets.end());

    int k = 2;

    while (!prevFreqItemsets.empty()) {
        set<Itemset> candidates = generateCandidates(prevFreqItemsets, k);
        ItemsetCount counts = countSupport(transactions, candidates);
        prevFreqItemsets = getFrequentItemsets(counts, min_support);
        freqItemsetsAll.insert(freqItemsetsAll.end(), prevFreqItemsets.begin(), prevFreqItemsets.end());
        k++;
    }

    cout << "\nFrequent Itemsets of Minimum Support >= " << min_support << "):\n";
    for (const auto &itemset : freqItemsetsAll) {
        for (const auto &item : itemset)
            cout<<item<<" ";
            cout<<endl;
    }

    return 0;
}
