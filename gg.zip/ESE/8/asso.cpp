#include <bits/stdc++.h>
using namespace std;

// Function to read CSV transactions
vector<vector<string>> readCSV(const string &filename) {
    vector<vector<string>> transactions;
    ifstream file(filename);
    string line;
    while (getline(file, line)) {
        vector<string> items;
        stringstream ss(line);
        string item;
        while (getline(ss, item, ',')) {
            item.erase(remove_if(item.begin(), item.end(), ::isspace), item.end());
            if (!item.empty()) items.push_back(item);
        }
        if (!items.empty()) transactions.push_back(items);
    }
    return transactions;
}

// Count how many transactions contain a given itemset
int countSupport(const vector<vector<string>> &transactions, const set<string> &itemset) {
    int count = 0;
    for (auto &t : transactions) {
        set<string> trans(t.begin(), t.end());
        if (includes(trans.begin(), trans.end(), itemset.begin(), itemset.end()))
            count++;
    }
    return count;
}

// Generate next-level candidate itemsets
set<set<string>> generateCandidates(const set<set<string>> &prevFreq, int k) {
    set<set<string>> candidates;
    for (auto it1 = prevFreq.begin(); it1 != prevFreq.end(); ++it1) {
        for (auto it2 = next(it1); it2 != prevFreq.end(); ++it2) {
            vector<string> v1(it1->begin(), it1->end());
            vector<string> v2(it2->begin(), it2->end());
            bool canJoin = true;
            for (int i = 0; i < k - 2; i++) {
                if (v1[i] != v2[i]) { canJoin = false; break; }
            }
            if (canJoin && v1[k - 2] != v2[k - 2]) {
                set<string> merged = *it1;
                merged.insert(v2[k - 2]);
                candidates.insert(merged);
            }
        }
    }
    return candidates;
}

// Apriori main process
map<set<string>, double> apriori(const vector<vector<string>> &transactions, double minSupport) {
    map<set<string>, double> supportCount;
    int totalTrans = transactions.size();

    // 1-itemsets
    map<string, int> itemCount;
    for (auto &t : transactions)
        for (auto &item : t)
            itemCount[item]++;

    set<set<string>> freqSet;
    for (auto &p : itemCount) {
        double support = (double)p.second / totalTrans;
        supportCount[{p.first}] = support;
        if (support >= minSupport)
            freqSet.insert({p.first});
    }

    cout << "\n--- Support of All Itemsets ---\n";
    for (auto &p : supportCount) {
        cout << "{ ";
        for (auto &x : p.first) cout << x << " ";
        cout << "} : " << fixed << setprecision(2) << p.second * 100 << "%\n";
    }

    // Higher-order itemsets
    set<set<string>> allFreq = freqSet;
    int k = 2;
    while (!freqSet.empty()) {
        set<set<string>> candidates = generateCandidates(freqSet, k);
        map<set<string>, double> candSupport;

        for (auto &cand : candidates) {
            int count = countSupport(transactions, cand);
            double support = (double)count / totalTrans;
            candSupport[cand] = support;
            supportCount[cand] = support;
        }

        freqSet.clear();
        for (auto &p : candSupport)
            if (p.second >= minSupport)
                freqSet.insert(p.first);

        allFreq.insert(freqSet.begin(), freqSet.end());
        k++;
    }

    cout << "\n--- Frequent Itemsets (>= min support) ---\n";
    for (auto &p : supportCount) {
        if (p.second >= minSupport) {
            cout << "{ ";
            for (auto &x : p.first) cout << x << " ";
            cout << "} : " << fixed << setprecision(2) << p.second * 100 << "%\n";
        }
    }

    return supportCount;
}

// Generate Association Rules
void generateRules(const vector<vector<string>> &transactions,
                   const map<set<string>, double> &supportCount,
                   double minConfidence) {

    cout << "\n--- Association Rules ---\n";
    for (auto &p : supportCount) {
        const set<string> &itemset = p.first;
        if (itemset.size() < 2) continue;

        vector<string> items(itemset.begin(), itemset.end());
        int n = items.size();
        for (int i = 1; i < (1 << n) - 1; i++) {
            set<string> A, B;
            for (int j = 0; j < n; j++) {
                if (i & (1 << j))
                    A.insert(items[j]);
                else
                    B.insert(items[j]);
            }

            if (A.empty() || B.empty()) continue;

            double supAB = supportCount.at(itemset);
            double supA = supportCount.count(A) ? supportCount.at(A) : (double)countSupport(transactions, A) / transactions.size();
            double conf = supAB / supA;

            if (conf >= minConfidence) {
                cout << "{ ";
                for (auto &a : A) cout << a << " ";
                cout << "} => { ";
                for (auto &b : B) cout << b << " ";
                cout << "} (Support = " << fixed << setprecision(2) << supAB * 100
                     << "%, Confidence = " << conf * 100 << "%)\n";
            }
        }
    }
}

int main() {
    string filename = "trans.csv";
    double minSupport, minConfidence;

    cout << "Enter minimum support (e.g., 0.3): ";
    cin >> minSupport;
    cout << "Enter minimum confidence (e.g., 0.6): ";
    cin >> minConfidence;

    vector<vector<string>> transactions = readCSV(filename);
    if (transactions.empty()) {
        cout << "No data found in " << filename << endl;
        return 0;
    }

    cout << "\nTotal Transactions: " << transactions.size() << "\n";

    auto supportCount = apriori(transactions, minSupport);
    generateRules(transactions, supportCount, minConfidence);

    return 0;
}
