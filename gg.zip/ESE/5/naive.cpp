#include <bits/stdc++.h>
using namespace std;

struct Record {
    string age, income, studying, credit, buysPC;
};

// Function to split a CSV line
vector<string> split(const string &line, char delimiter = ',') {
    vector<string> tokens;
    string token;
    stringstream ss(line);
    while (getline(ss, token, delimiter))
        tokens.push_back(token);
    return tokens;
}

int main() {
    string filename = "data.csv"; // dataset filename
    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Error opening file.\n";
        return 1;
    }

    vector<Record> data;
    string line;
    getline(file, line); // skip header

    while (getline(file, line)) {
        vector<string> row = split(line, ',');
        if (row.size() != 5) continue;
        Record r = {row[0], row[1], row[2], row[3], row[4]};
        data.push_back(r);
    }
    file.close();

    // Input test case
    Record test;
    cout << "Enter details to predict (Age Income Studying CreditRate):\n";
    cin >> test.age >> test.income >> test.studying >> test.credit;

    // Count totals for class labels
    map<string, int> classCount;
    for (auto &r : data) classCount[r.buysPC]++;

    int total = data.size();
    double probYes = (double)classCount["yes"] / total;
    double probNo = (double)classCount["no"] / total;

    // Count attribute-wise conditional probabilities
    map<string, int> ageYes, incomeYes, studyYes, creditYes;
    map<string, int> ageNo, incomeNo, studyNo, creditNo;

    for (auto &r : data) {
        if (r.buysPC == "yes") {
            ageYes[r.age]++;
            incomeYes[r.income]++;
            studyYes[r.studying]++;
            creditYes[r.credit]++;
        } else {
            ageNo[r.age]++;
            incomeNo[r.income]++;
            studyNo[r.studying]++;
            creditNo[r.credit]++;
        }
    }

    // Calculate conditional probabilities P(attr|yes) and P(attr|no)
    double pAgeYes = (double)ageYes[test.age] / classCount["yes"];
    double pIncomeYes = (double)incomeYes[test.income] / classCount["yes"];
    double pStudyYes = (double)studyYes[test.studying] / classCount["yes"];
    double pCreditYes = (double)creditYes[test.credit] / classCount["yes"];

    double pAgeNo = (double)ageNo[test.age] / classCount["no"];
    double pIncomeNo = (double)incomeNo[test.income] / classCount["no"];
    double pStudyNo = (double)studyNo[test.studying] / classCount["no"];
    double pCreditNo = (double)creditNo[test.credit] / classCount["no"];

    // Apply Naive Bayes formula
    double yesProb = probYes * pAgeYes * pIncomeYes * pStudyYes * pCreditYes;
    double noProb = probNo * pAgeNo * pIncomeNo * pStudyNo * pCreditNo;

    cout << "\nP(Yes) = " << yesProb << "\nP(No) = " << noProb << endl;
    cout << "\nPredicted Class: " << (yesProb > noProb ? "YES" : "NO") << endl;

    return 0;
}
